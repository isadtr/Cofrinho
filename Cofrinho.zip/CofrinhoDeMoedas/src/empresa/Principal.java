package empresa;

public class Principal {
	public static void main(String[] args) {
		Menu menu = new Menu();  // Cria uma instância da classe Menu
        menu.exibirMenu();  // Chama o método exibirMenu() da instância do Menu
}
}